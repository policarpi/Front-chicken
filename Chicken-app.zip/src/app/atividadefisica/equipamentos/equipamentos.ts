export class Equipamentos{
  id: number;
  nome: string;
}
