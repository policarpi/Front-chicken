import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treinos-form',
  templateUrl: './treinos-form.component.html',
  styleUrls: ['./treinos-form.component.css']
})
export class TreinosFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
