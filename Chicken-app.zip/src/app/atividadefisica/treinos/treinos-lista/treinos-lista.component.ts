import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-treinos-lista',
  templateUrl: './treinos-lista.component.html',
  styleUrls: ['./treinos-lista.component.css']
})
export class TreinosListaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
