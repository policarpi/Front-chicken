export class Treinos{
  id: number;
  idEquipamentos: number;
  idPessoa: number;
  quantidade: number;
  repeticao: number;
  peso: number;
  ficha: number;
}
