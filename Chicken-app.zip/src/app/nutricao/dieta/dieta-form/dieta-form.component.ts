import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dieta-form',
  templateUrl: './dieta-form.component.html',
  styleUrls: ['./dieta-form.component.css']
})
export class DietaFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
