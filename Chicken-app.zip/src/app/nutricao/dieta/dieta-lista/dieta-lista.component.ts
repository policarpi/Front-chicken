import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dieta-lista',
  templateUrl: './dieta-lista.component.html',
  styleUrls: ['./dieta-lista.component.css']
})
export class DietaListaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
