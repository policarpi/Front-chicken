export class Dietas{
  id:number;
  idPessoa:number;
  idAlimentos:number;
  idRefeicoes:number;
  quantidade:number;
}
