export class Refeicoes{
  id:number;
  tiporefeicoes:string;
}
