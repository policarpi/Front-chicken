import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enderecos-form',
  templateUrl: './enderecos-form.component.html',
  styleUrls: ['./enderecos-form.component.css']
})
export class EnderecosFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
