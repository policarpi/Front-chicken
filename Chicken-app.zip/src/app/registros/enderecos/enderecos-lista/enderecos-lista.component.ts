import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enderecos-lista',
  templateUrl: './enderecos-lista.component.html',
  styleUrls: ['./enderecos-lista.component.css']
})
export class EnderecosListaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
