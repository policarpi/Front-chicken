export class Endereco{
  id:number;
  idPessoa:number;
  cep:string;
  endereco:string;
  numero:number;
  cidade:string;
  estado:string;

}
