export class Pessoas{
  id:number;
  nome:string;
  sobreNome:string;
  dataNacimento:string;
  eMail:string;
  cpf:string;
}
