import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RegistrosRoutingModule } from './registros-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RegistrosRoutingModule
  ]
})
export class RegistrosModule { }
